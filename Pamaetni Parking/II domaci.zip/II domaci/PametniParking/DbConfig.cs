﻿namespace PametniParkingLibrary;

internal static class DbConfig
{
    // ZAMENI TvojUsername i TvojaLozinka svojim stvarnim Oracle kredencijalima
    public const string ConnectionString =
        "DATA SOURCE=gislab-oracle.elfak.ni.ac.rs:1521/SBP_PDB;PERSIST SECURITY INFO=True;USER ID=S19716;Password=S19716";
}
